# Movie Database Viewing Instructions
The main instructions for setting up the database

## Contributers
* Evan Hunter Bowman
* Evan Whitmer
* McCade Freeman

## Installation instructions
These instructions are based on the powerpoint 23-WebProgrammingWithPHP
* Download and install XAMPP
  - https://www.apachefriends.org/index.html
  
* Open XAMPP Manager

Once you have completed installation, open up the XAMPP Control Panel.

Start all of the Services. If your "MySQL Database" server is still NOT running then click the "Configure" button on the right hand side of the MySQL Service listed. Now open the configure file and change all the mentions of port 3306 to another port number that is not currently being used.


